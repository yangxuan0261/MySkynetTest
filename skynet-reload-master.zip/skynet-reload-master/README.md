## What's this ?

A library for reload a lua service.

## Build

Modify the Makefile, change SKYNET_PATH to your path of skynet. The default path is $(HOME)/skynet .

If you are not using linux, make it by yourself.

## Test

```
$(HOME)/skynet test/config
```
